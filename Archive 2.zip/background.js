let offscreenDocument = null; // Variable to track the offscreen document

function idkwhattocallthis() {
  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    try {
      if (message.action === "playAudio") {
        // Always create a new offscreen document, regardless of the previous one
        createOffscreenDocument();
      }
    } catch (error) {
      if (error.message.startsWith('Only a single offscreen')) {
        console.error('Error setting up offscreen document:', error);
        // Close the current offscreen document and try again
        if (offscreenDocument) {
          chrome.offscreen.closeDocument(offscreenDocument, () => {
            console.log("Offscreen document closed due to error.");
          });
          offscreenDocument = null;
        }

        // Recursive call to retry
        idkwhattocallthis();
      }
    }
  });
  function createOffscreenDocument() {
    chrome.offscreen.createDocument({
      url: chrome.runtime.getURL('audio.html'),
      reasons: ['AUDIO_PLAYBACK'],
      justification: 'Notification',
    }, (doc) => {
      offscreenDocument = doc; // Store the reference to the newly created offscreen document
      console.log("New offscreen document created.");
    });
  }
  // Listener for the "audioFinished" message outside of the document creation logic
  chrome.runtime.onMessage.addListener((msg) => {
    if (msg.message === "audioFinished") {
      if (offscreenDocument) {
        chrome.offscreen.closeDocument(offscreenDocument, () => {
          console.log("Audio finished and offscreen document closed.");
        });
        offscreenDocument = null; // Reset after closing the document
      }
    }
  });
}



// Call the function initially
idkwhattocallthis();
