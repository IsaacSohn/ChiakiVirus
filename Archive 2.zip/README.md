# Sechify
A chrome extension that makes every thumbnail on youtube have art from the artist BlueSechi

I got this idea from MrBeastify and Jambofy
A lot of guidance and just generally how to approach certain tasks was given by looking at the code from those 2 extensions.

Jambofy: https://github.com/LiamHarrison25/Jambofy-Extension

Mrbeastify: https://github.com/MagicJinn/MrBeastify-Youtube

Feel free to modify my extension to make whatever you like. I put a lot of comments to explain the entire thing :) (just credit me or smth lmao)

Support me on kofi if you want and can: https://ko-fi.com/chikenuwu
